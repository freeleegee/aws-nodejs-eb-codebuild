# **AWS Elastic Beanstalk NodeJS Sample Application**

Sample Elastic Beanstalk / CodeBuild / Mocha / CodePipeline NodeJS application from the BackSpace Academy AWS certification preparation course.
https://backspace.academy/
